package com.sjsu.se195.uniride.viewholder;

import android.view.View;

/**
 * Created by timhdavis on 4/15/18.
 */

public interface OnItemClickListener {
    void onClick(View view, int position);
}

package com.sjsu.se195.uniride.models;

/**
 * Created by akshat on 2/4/18.
 */

//LATITUDE, LONGITUDE FROM MAPS API and HELPER FUNCTIONS

public class Location {
}
